import tkinter as tk
from tkinter import ttk, messagebox
from .report_functions import generate_report

class ReportFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.create_widgets()

    def create_widgets(self):
        # Title
        title_label = tk.Label(self, text="Generate Report", font=("Helvetica", 16))
        title_label.grid(row=0, column=0, columnspan=2, pady=20)

        # Report Type
        report_type_label = tk.Label(self, text="Report Type:")
        report_type_label.grid(row=1, column=0, sticky="e", padx=5, pady=5)
        self.report_type_var = tk.StringVar()
        report_type_combobox = ttk.Combobox(self, textvariable=self.report_type_var)
        report_type_combobox['values'] = ('Daily', 'Weekly', 'Monthly')
        report_type_combobox.grid(row=1, column=1, padx=5, pady=5)
        report_type_combobox.set('Daily')

        # Date Range
        start_date_label = tk.Label(self, text="Start Date:")
        start_date_label.grid(row=2, column=0, sticky="e", padx=5, pady=5)
        self.start_date_entry = tk.Entry(self)
        self.start_date_entry.grid(row=2, column=1, padx=5, pady=5)
        self.start_date_entry.insert(0, "YYYY-MM-DD")

        end_date_label = tk.Label(self, text="End Date:")
        end_date_label.grid(row=3, column=0, sticky="e", padx=5, pady=5)
        self.end_date_entry = tk.Entry(self)
        self.end_date_entry.grid(row=3, column=1, padx=5, pady=5)
        self.end_date_entry.insert(0, "YYYY-MM-DD")

        # Generate Report Button
        generate_button = tk.Button(self, text="Generate Report", command=self.generate_report)
        generate_button.grid(row=4, column=0, columnspan=2, pady=20)

        # Report Display Area
        self.report_display = tk.Text(self, height=10, width=50)
        self.report_display.grid(row=5, column=0, columnspan=2, padx=5, pady=5)
        self.report_display.config(state=tk.DISABLED)

    def generate_report(self):
        report_type = self.report_type_var.get()
        start_date = self.start_date_entry.get()
        end_date = self.end_date_entry.get()

        if not report_type or start_date == "YYYY-MM-DD" or end_date == "YYYY-MM-DD":
            messagebox.showerror("Error", "Please fill in all fields.")
            return

        # Call the function to generate the report
        report_content = generate_report(report_type, start_date, end_date)

        # Display the report
        self.report_display.config(state=tk.NORMAL)
        self.report_display.delete(1.0, tk.END)
        self.report_display.insert(tk.END, report_content)
        self.report_display.config(state=tk.DISABLED)