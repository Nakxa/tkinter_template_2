import json

def save_settings(theme, language, notifications, autosave_interval):
    settings = {
        'theme': theme,
        'language': language,
        'notifications': notifications,
        'autosave_interval': autosave_interval
    }
    try:
        with open('settings.json', 'w') as f:
            json.dump(settings, f)
        return True
    except Exception as e:
        print(f"An error occurred while saving settings: {e}")
        return False

def load_settings():
    try:
        with open('settings.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        # Return default settings if file doesn't exist
        return {
            'theme': 'Light',
            'language': 'English',
            'notifications': True,
            'autosave_interval': 5
        }
    except Exception as e:
        print(f"An error occurred while loading settings: {e}")
        return None