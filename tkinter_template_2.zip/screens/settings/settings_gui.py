import tkinter as tk
from tkinter import ttk, messagebox
from .settings_functions import save_settings, load_settings

class SettingsFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.create_widgets()

    def create_widgets(self):
        # Title
        title_label = tk.Label(self, text="Settings", font=("Helvetica", 16))
        title_label.grid(row=0, column=0, columnspan=2, pady=20)

        # Theme
        theme_label = tk.Label(self, text="Theme:")
        theme_label.grid(row=1, column=0, sticky="e", padx=5, pady=5)
        self.theme_var = tk.StringVar()
        theme_combobox = ttk.Combobox(self, textvariable=self.theme_var)
        theme_combobox['values'] = ('Light', 'Dark')
        theme_combobox.grid(row=1, column=1, padx=5, pady=5)

        # Language
        language_label = tk.Label(self, text="Language:")
        language_label.grid(row=2, column=0, sticky="e", padx=5, pady=5)
        self.language_var = tk.StringVar()
        language_combobox = ttk.Combobox(self, textvariable=self.language_var)
        language_combobox['values'] = ('English', 'Spanish', 'French')
        language_combobox.grid(row=2, column=1, padx=5, pady=5)

        # Notifications
        self.notifications_var = tk.BooleanVar()
        notifications_checkbox = tk.Checkbutton(self, text="Enable Notifications", variable=self.notifications_var)
        notifications_checkbox.grid(row=3, column=0, columnspan=2, pady=5)

        # Auto-save Interval
        autosave_label = tk.Label(self, text="Auto-save Interval (minutes):")
        autosave_label.grid(row=4, column=0, sticky="e", padx=5, pady=5)
        self.autosave_entry = tk.Entry(self)
        self.autosave_entry.grid(row=4, column=1, padx=5, pady=5)

        # Save Settings Button
        save_button = tk.Button(self, text="Save Settings", command=self.save_settings)
        save_button.grid(row=5, column=0, columnspan=2, pady=20)

        # Load current settings
        self.load_current_settings()

    def save_settings(self):
        theme = self.theme_var.get()
        language = self.language_var.get()
        notifications = self.notifications_var.get()
        autosave_interval = self.autosave_entry.get()

        if not theme or not language or not autosave_interval:
            messagebox.showerror("Error", "Please fill in all fields.")
            return

        try:
            autosave_interval = int(autosave_interval)
        except ValueError:
            messagebox.showerror("Error", "Auto-save interval must be a number.")
            return

        # Call the function to save settings
        success = save_settings(theme, language, notifications, autosave_interval)

        if success:
            messagebox.showinfo("Success", "Settings saved successfully.")
        else:
            messagebox.showerror("Error", "Failed to save settings. Please try again.")

    def load_current_settings(self):
        # Load current settings and update the UI
        settings = load_settings()
        if settings:
            self.theme_var.set(settings['theme'])
            self.language_var.set(settings['language'])
            self.notifications_var.set(settings['notifications'])
            self.autosave_entry.insert(0, str(settings['autosave_interval']))