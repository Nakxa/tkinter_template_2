import tkinter as tk

class DashboardFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        label = tk.Label(self, text="Dashboard Content")
        label.pack(pady=20)