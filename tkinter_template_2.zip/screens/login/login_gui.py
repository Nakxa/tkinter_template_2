import tkinter as tk
import customtkinter as ctk
from PIL import Image, ImageTk
import base64
from io import BytesIO
from assets.icons.profile_icon import icon_base64_img
from assets.images.bg_img import bg_base64_img


bg_base64 = bg_base64_img
icon_base64 = icon_base64_img

# Decode base64 string to an image
def base64_to_image(base64_str):
    image_data = base64.b64decode(base64_str)
    return Image.open(BytesIO(image_data))



class LoginFrame(tk.Frame):
    def __init__(self, master, on_login_success):
        super().__init__(master)
        self.master = master
        self.on_login_success = on_login_success
        self.master.title("login window")
         # Get screen dimensions
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()

        # Create and place widgets
        self.create_widgets(screen_width, screen_height)

    def create_widgets(self, screen_width, screen_height):
        # Load and set background image from base64
        bg_image = base64_to_image(bg_base64)
        bg_image = bg_image.resize((screen_width, screen_height), Image.LANCZOS)
        self.bg_photo = ImageTk.PhotoImage(bg_image)
        self.bg_label = tk.Label(self, image=self.bg_photo)
        self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)

        # Create login frame
        self.login_frame = ctk.CTkFrame(self, width=360, height=500)
        self.login_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        # Add login components
        self.login_label = ctk.CTkLabel(self.login_frame, text="Data Logger Login", font=("Arial", 24, "bold"))
        self.login_label.place(x=180, y=100, anchor=tk.CENTER)

        # Load and display app icon from base64
        icon_image = base64_to_image(icon_base64)
        icon_image = icon_image.resize((64, 64), Image.LANCZOS)
        self.icon_photo = ImageTk.PhotoImage(icon_image)
        self.icon_label = tk.Label(self.login_frame, image=self.icon_photo, bd=0, highlightthickness=0)
        self.icon_label.place(x=180, y=175, anchor=tk.CENTER)

        # Username and password entries
        self.username_entry = ctk.CTkEntry(self.login_frame, width=260, placeholder_text="Username")
        self.username_entry.place(x=180, y=250, anchor=tk.CENTER)

        self.password_entry = ctk.CTkEntry(self.login_frame, width=260, placeholder_text="Password", show="*")
        self.password_entry.place(x=180, y=300, anchor=tk.CENTER)

        # Login button
        self.login_button = ctk.CTkButton(self.login_frame, text="Login", width=200, command=self.login)
        self.login_button.place(x=180, y=370, anchor=tk.CENTER)
      
    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        if username == "admin" and password == "admin":
            self.show_loading()
        else:
            ctk.CTkMessageBox.show_error(title="Login Failed", message="Invalid username or password")

    def show_loading(self):
        self.loading_label = ctk.CTkLabel(self, text="Logging in...", font=("Arial", 16))
        self.loading_label.place(relx=0.5, rely=0.7, anchor=tk.CENTER)
        self.after(2000, self.finish_login)

    def finish_login(self):
        self.loading_label.destroy()
        print("Login successful")
        # You can call the next screen transition here