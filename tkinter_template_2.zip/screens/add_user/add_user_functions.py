import sqlite3
import hashlib

def add_user_to_database(username, password, user_type):
    try:
        # Connect to SQLite database (or create it if it doesn't exist)
        conn = sqlite3.connect('data_logger.db')
        cursor = conn.cursor()

        # Create users table if it doesn't exist
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS users
        (id INTEGER PRIMARY KEY,
         username TEXT UNIQUE NOT NULL,
         password TEXT NOT NULL,
         user_type TEXT NOT NULL)
        ''')

        # Hash the password
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        # Insert new user
        cursor.execute('''
        INSERT INTO users (username, password, user_type)
        VALUES (?, ?, ?)
        ''', (username, hashed_password, user_type))

        # Commit changes and close connection
        conn.commit()
        conn.close()

        return True
    except sqlite3.IntegrityError:
        # This error is raised if the username already exists
        return False
    except Exception as e:
        print(f"An error occurred: {e}")
        return False
