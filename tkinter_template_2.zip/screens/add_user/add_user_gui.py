import tkinter as tk
from tkinter import ttk, messagebox
from .add_user_functions import add_user_to_database

class AddUserFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.create_widgets()

    def create_widgets(self):
        # Title
        title_label = tk.Label(self, text="Add New User", font=("Helvetica", 16))
        title_label.grid(row=0, column=0, columnspan=2, pady=20)

        # Username
        username_label = tk.Label(self, text="Username:")
        username_label.grid(row=1, column=0, sticky="e", padx=5, pady=5)
        self.username_entry = tk.Entry(self)
        self.username_entry.grid(row=1, column=1, padx=5, pady=5)

        # Password
        password_label = tk.Label(self, text="Password:")
        password_label.grid(row=2, column=0, sticky="e", padx=5, pady=5)
        self.password_entry = tk.Entry(self, show="*")
        self.password_entry.grid(row=2, column=1, padx=5, pady=5)

        # Confirm Password
        confirm_password_label = tk.Label(self, text="Confirm Password:")
        confirm_password_label.grid(row=3, column=0, sticky="e", padx=5, pady=5)
        self.confirm_password_entry = tk.Entry(self, show="*")
        self.confirm_password_entry.grid(row=3, column=1, padx=5, pady=5)

        # User Type
        user_type_label = tk.Label(self, text="User Type:")
        user_type_label.grid(row=4, column=0, sticky="e", padx=5, pady=5)
        self.user_type_var = tk.StringVar()
        user_type_combobox = ttk.Combobox(self, textvariable=self.user_type_var)
        user_type_combobox['values'] = ('Admin', 'Regular User')
        user_type_combobox.grid(row=4, column=1, padx=5, pady=5)
        user_type_combobox.set('Regular User')

        # Add User Button
        add_user_button = tk.Button(self, text="Add User", command=self.add_user)
        add_user_button.grid(row=5, column=0, columnspan=2, pady=20)

    def add_user(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        confirm_password = self.confirm_password_entry.get()
        user_type = self.user_type_var.get()

        if not username or not password:
            messagebox.showerror("Error", "Username and password are required.")
            return

        if password != confirm_password:
            messagebox.showerror("Error", "Passwords do not match.")
            return

        # Call the function to add user to the database
        success = add_user_to_database(username, password, user_type)

        if success:
            messagebox.showinfo("Success", f"User '{username}' added successfully.")
            self.clear_entries()
        else:
            messagebox.showerror("Error", "Failed to add user. Please try again.")

    def clear_entries(self):
        self.username_entry.delete(0, tk.END)
        self.password_entry.delete(0, tk.END)
        self.confirm_password_entry.delete(0, tk.END)
        self.user_type_var.set('Regular User')